# golang-http-file-upload-download

 A simple example of an HTTP upload and download in Go 

 Start with

 ```
 go run main.go
 ```
